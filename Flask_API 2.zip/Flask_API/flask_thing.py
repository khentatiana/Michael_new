from flask import Flask, render_template, request
import math
import json
import random

app = Flask(__name__)


@app.route('/')
def main():
    return render_template('main.html')


@app.route('/temp')
def generate_temp():
    temperature = random.randint(-30, 40)
    country = random.choice(json.load(open('countries.txt', 'r')))

    html = f'<h1>Сейчас в {country} {temperature} градусов.</h1>'
    html += '<h2>Вот вам картинка описывая критичную ситуацы:</h2>'

    if temperature <= 10:
        html += '<img src = "/static/snowy.jpeg" />'
        html += '<h2>Сежный опакалипсис!</h2>'

    if 10 < temperature <= 24:
        html += '<img src = "/static/normalicy.jpg" />'
        html += '<h2>Как обычно... Без проблем... Не бомби.</h2>'

    if temperature > 24:
        html += '<img src = "/static/new_hot.jpeg" />'
        html += '<h1>Возми пивка, выйди на улицу и станцуй под хардбасс потому что сегодня жарко.</h2>'

    return html


@app.route('/save')
def save():
    card_num = request.args.get('card_number', None)
    if card_num:
        print('Номер карты: ' + card_num)

    return render_template('save.html')


@app.route('/fake')
def fake():
    return render_template('fake.html')


@app.route('/calculator')
def calculator():
    return render_template('calculator.html')


@app.route('/calculator/pythag')
def pythagorean():
    return render_template('pythagorean.html')


@app.route('/calculator/pythagorean_calculated')
def calc_pythagorean():
    a = int(request.args.get('a', None))
    b = int(request.args.get('b', None))
    html = ''
    if a and b:
        html = f'<h1>c = {math.sqrt(a ** 2 + b ** 2)}</h1>'
    html += """
    <ul>
        <li>
            <a href="http://127.0.0.1:5000"> Return to main menu</a>
        </li>
    </ul>
    """
    return html


@app.route('/calculator/surface_area')
def calc_surface_area():
    return render_template('surface_areas.html')


@app.route('/calculator/surface_area/cube')
def calculate_cube():
    return render_template('cube.html')


@app.route('/calculator/surface_area/rectangular_prism')
def calculate_rectangle():
    return render_template('rectangular_prism.html')


@app.route('/calculator/surface_area/shpere')
def calculate_sphere():
    return render_template('shpere.html')


@app.route('/calculator/surface_area/сylinder')
def calculate_cylinder():
    return render_template('cylinder.html')


@app.route('/calculator/surface_area/сube/calculate_it')
def cube_c():
    s = int(request.args.get('s', None))
    html = ''
    if s:
        html = f'<h1>Surface Area = {6 * s}</h1>'
        html += f'<h1>Volume = {s**3}</h1>'
    html += """
    <ul>
        <li>
            <a href="http://127.0.0.1:5000"> Return to main menu</a>
        </li>
    </ul>
    """
    return html


@app.route('/calculator/surface_area/rectangular_prism/calculate_it')
def rectangle_c():
    l = int(request.args.get('l', None))
    h = int(request.args.get('h', None))
    w = int(request.args.get('w', None))
    html = ''
    if l and h and w:
        html = f'<h1>Surface Area = {2 * (l * w + l * h + h * w)}</h1>'
        html += f'<h1>Volume = {l * h * w}</h1>'
    html += """
        <ul>
            <li>
                <a href="http://127.0.0.1:5000"> Return to main menu</a>
            </li>
        </ul>
        """
    return html


@app.route('/calculator/surface_area/shpere/calculate_it')
def sphere_c():
    r = int(request.args.get('r', None))
    pi = 3.14
    html = ''
    if r:
        html += f'<h1>Surface Area = {4 * pi * r**2}</h1>'
        html += f'<h1>Volume = {4/3 * pi * r**3}</h1>'
    html += """
    <ul>
        <li>
            <a href="http://127.0.0.1:5000"> Return to main menu</a>
        </li>
    </ul>
    """
    return html


@app.route('/calculator/surface_area/сylinder/calculate_it')
def cylinder_c():
    r = int(request.args.get('r', None))
    h = int(request.args.get('h', None))
    pi = 3.14
    html = ''

    if r and h:
        html = f'<h1>Surface Area = {(2 * r * pi) * h + 2 * r**2 * pi}</h1>'
        html += f'<h1>Volume = {(r**2 * pi) * h}</h1>'

    html += """
    <ul>
        <li>
            <a href="http://127.0.0.1:5000"> Return to main menu</a>
        </li>
    </ul>
    """
    return html


app.run(debug=True)
