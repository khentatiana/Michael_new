from flask import Flask
import json
import random

app = Flask(__name__)


@app.route('/')
def generate_temp():
    temperature = random.randint(-30, 40)
    country = random.choice(json.load(open('countries.txt', 'r')))

    html = f'<h1>Сейчас в {country} {temperature} градусов.</h1>'
    html += '<h2> Вот вам кортинка описывая критичную ситуацы:</h2>'

    if temperature <= 10:
        html += '<img src = "/static/snowy.jpeg" />'

    if 10 < temperature <= 24:
        html += '<img src = "/static/normalicy.jpg" />'

    if temperature > 24:
        html += '<img src = "/static/new_hot.jpeg" />'

    return html


app.run(debug=True)
